using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreCounter : MonoBehaviour
{
    int score;
    private PlayerController pcScript;
    public Text text;

    // Start is called before the first frame update
    void Start()
    {
        score = 0;
        pcScript = GameObject.Find("Player").GetComponent<PlayerController>();
    }

    // Update is called once per frame
    void Update()
    {
        text.text = "" + score;

        if (pcScript.dash && !pcScript.gameOver)
        {
            score += 2;
        }
        else if (!pcScript.dash && !pcScript.gameOver)
        {
            score++;
        }
    }
}
